In order to run this game, you will need to get the RENPY launcher
Renpy is the engine we are using in tandum with UNITY.
https://www.renpy.org/


This is just the prototype. How the text works, what language we are using, etc.